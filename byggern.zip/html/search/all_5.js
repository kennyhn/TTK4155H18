var searchData=
[
  ['joystick_5fperc_5fangle',['Joystick_perc_angle',['../structJoystick__perc__angle.html',1,'']]],
  ['joystick_5fraw_5fdata',['Joystick_raw_data',['../structJoystick__raw__data.html',1,'']]],
  ['joystick_5fx_5faxis',['joystick_x_axis',['../adc_8h.html#ab94116694c3f3315e4afacfa735f17ea',1,'adc.c']]],
  ['joystick_5fy_5faxis',['joystick_y_axis',['../adc_8h.html#aeb5f1126dd9648575f8dd2b35cccb92a',1,'adc.c']]]
];
