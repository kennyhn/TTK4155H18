var searchData=
[
  ['save_5fhigh_5fscore',['save_high_score',['../game_8h.html#a8df847e88f6b72bef5829895fcdabc5f',1,'game.c']]],
  ['send_5fconsole_5fmessage',['send_console_message',['../can_8h.html#a23bd093368b41b950c11ea4054a29253',1,'can.c']]],
  ['set_5fmotor_5fstart_5fpoint',['set_motor_start_point',['../motor__node2_8h.html#ab9bacff9c3030ec0fb7e11814041ce6a',1,'motor_node2.c']]],
  ['solenoid_5fcontrol',['solenoid_control',['../pwm__node2_8h.html#a236a52a87db1ae5c8ca38144717a6c9c',1,'pwm_node2.c']]],
  ['spi_5fmaster_5finit',['SPI_master_init',['../spi_8h.html#aea7de5dd2d8e9d42343749550831ebbc',1,'SPI_master_init(void):&#160;spi.c'],['../spi__node2_8h.html#aea7de5dd2d8e9d42343749550831ebbc',1,'SPI_master_init(void):&#160;spi.c']]],
  ['spi_5fmaster_5freceive',['SPI_master_receive',['../spi_8h.html#a991439e225cfd241b48aaf85fc5ef5d8',1,'SPI_master_receive(void):&#160;spi.c'],['../spi__node2_8h.html#a991439e225cfd241b48aaf85fc5ef5d8',1,'SPI_master_receive(void):&#160;spi.c']]],
  ['spi_5fmaster_5ftransmit',['SPI_master_transmit',['../spi_8h.html#af6368b67e2ba591bcd82ca58e7bc05e2',1,'SPI_master_transmit(char cData):&#160;spi.c'],['../spi__node2_8h.html#af6368b67e2ba591bcd82ca58e7bc05e2',1,'SPI_master_transmit(char cData):&#160;spi.c']]],
  ['sram_5foled_5fprint4',['SRAM_oled_print4',['../oled_8h.html#a9dc2f69c4dfc53277f41cf9a388f70c1',1,'oled.c']]],
  ['sram_5foled_5fprint5',['SRAM_oled_print5',['../oled_8h.html#acac109e0aba9f1949035cf9fd6a3e2d3',1,'oled.c']]],
  ['sram_5foled_5fprint8',['SRAM_oled_print8',['../oled_8h.html#aa91660a084d844c19d2e5af325844fdc',1,'oled.c']]],
  ['sram_5foled_5freset',['SRAM_OLED_reset',['../sram_8h.html#aec8f10a863657b6c95a72eab64bc654a',1,'sram.c']]],
  ['sram_5foled_5fwrite_5fcharacter_5ffont4',['SRAM_oled_write_character_font4',['../oled_8h.html#a84e60c45f1ebd5d46f4734254644168d',1,'oled.c']]],
  ['sram_5foled_5fwrite_5fcharacter_5ffont5',['SRAM_oled_write_character_font5',['../oled_8h.html#a8cde432e6b2d81af8f800581ba34b0b1',1,'oled.c']]],
  ['sram_5foled_5fwrite_5fcharacter_5ffont8',['SRAM_oled_write_character_font8',['../oled_8h.html#a56d9d9683bf709adb238a0d9d665ae45',1,'oled.c']]],
  ['sram_5fread_5foled_5fdata',['SRAM_read_oled_data',['../sram_8h.html#afc9c8dfb3a599a5cf8b479790a8b921c',1,'sram.c']]],
  ['sram_5ftest',['SRAM_test',['../sram_8h.html#a2e2934cf8f43363e11e4fd6c60db1666',1,'sram.c']]],
  ['sram_5fwrite_5fto_5fmem',['SRAM_write_to_mem',['../sram_8h.html#a17a8be595ede70d9bfe7b24046a91661',1,'sram.c']]],
  ['sram_5fwrites_5fto_5fscreen',['SRAM_writes_to_screen',['../sram_8h.html#a2f981d283bd182e3cd80ea238af8e303',1,'sram.c']]]
];
