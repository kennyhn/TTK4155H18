var searchData=
[
  ['twi_5fstatusreg',['TWI_statusReg',['../unionTWI__statusReg.html',1,'']]]
];
