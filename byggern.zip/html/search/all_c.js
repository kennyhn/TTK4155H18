var searchData=
[
  ['timer_2eh',['timer.h',['../timer_8h.html',1,'']]],
  ['timer_5finterrupt_5finit',['timer_interrupt_init',['../timer_8h.html#a8028419a1ef437119887d7db4cc3c044',1,'timer_interrupt_init(void):&#160;timer.c'],['../pwm__node2_8h.html#a6d273aee79b3dfaecb3817f917355e2e',1,'timer_interrupt_init():&#160;timer.c']]],
  ['transform_5fencoder_5fto_5fposition',['transform_encoder_to_position',['../motor__node2_8h.html#a569306bc63fad41649987d6fbae8b31c',1,'motor_node2.c']]],
  ['twi_5fmaster_5fnode2_2eh',['TWI_Master_node2.h',['../TWI__Master__node2_8h.html',1,'']]],
  ['twi_5fstatusreg',['TWI_statusReg',['../unionTWI__statusReg.html',1,'']]]
];
