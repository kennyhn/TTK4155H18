var searchData=
[
  ['high_5fscore_5finit',['high_score_init',['../game_8h.html#adb508ab4167ca9d196d862d390289c26',1,'game.c']]]
];
