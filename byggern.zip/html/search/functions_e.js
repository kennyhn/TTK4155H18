var searchData=
[
  ['write_5fc',['write_c',['../oled_8h.html#a4a41585e36416165f42fbbfd3fcaa853',1,'oled.c']]]
];
