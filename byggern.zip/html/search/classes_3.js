var searchData=
[
  ['slider_5fraw_5fdata',['Slider_raw_data',['../structSlider__raw__data.html',1,'']]]
];
