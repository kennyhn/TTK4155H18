var searchData=
[
  ['play_5fgame',['play_game',['../game_8h.html#ae37b8386ad0b6e6957095d0aa9567a69',1,'play_game(uint8_t K_p, uint8_t K_i):&#160;game.c'],['../game__node2_8h.html#a191e479e7bcd63ad44a072e0b41a9a31',1,'play_game(void):&#160;game_node2.c']]],
  ['print_5fgame_5fscreen',['print_game_screen',['../game_8h.html#a605805bc93ef71e9da3df7bb22a9b1e3',1,'game.c']]],
  ['print_5fhigh_5fscore',['print_high_score',['../game_8h.html#a42b428ae1f1c2d312a60d442ae2fac5c',1,'game.c']]],
  ['print_5fmarker',['print_marker',['../menu_8h.html#a773d10b1fabfb90fba0003b9048f7cd7',1,'menu.c']]],
  ['print_5fpage',['print_page',['../menu_8h.html#af2f57b0437a1b323064e18c4804ce0f3',1,'menu.c']]],
  ['print_5fpixel',['print_pixel',['../oled_8h.html#aba8b1158d9e0973f5489dac93d8c0a4f',1,'oled.c']]],
  ['print_5fscore',['print_score',['../game_8h.html#ae4fa86c99c07dbfd696ac44c05c71d83',1,'game.c']]],
  ['pwm_5fdriver',['pwm_driver',['../pwm__node2_8h.html#a7e10b98b10a99a42cfd6b317e0214c76',1,'pwm_node2.c']]],
  ['pwm_5finit',['pwm_init',['../pwm__node2_8h.html#a1e8fdae3fd7118582ffa427dad05b6e1',1,'pwm_node2.c']]],
  ['pwm_5fnode2_2eh',['pwm_node2.h',['../pwm__node2_8h.html',1,'']]]
];
