var searchData=
[
  ['user_5fscore',['User_score',['../structUser__score.html',1,'']]]
];
