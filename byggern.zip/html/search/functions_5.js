var searchData=
[
  ['joystick_5fx_5faxis',['joystick_x_axis',['../adc_8h.html#ab94116694c3f3315e4afacfa735f17ea',1,'adc.c']]],
  ['joystick_5fy_5faxis',['joystick_y_axis',['../adc_8h.html#aeb5f1126dd9648575f8dd2b35cccb92a',1,'adc.c']]]
];
